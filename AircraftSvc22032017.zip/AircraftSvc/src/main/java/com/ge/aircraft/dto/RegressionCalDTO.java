/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.dto;

import javax.xml.bind.annotation.XmlRootElement;

import org.json.simple.JSONArray;

/**
 * 
 * @author predix -
 */
@XmlRootElement
public class RegressionCalDTO {
	
	
	private JSONArray Coeff;
	private JSONArray StdError;
	private JSONArray pValue;
	private JSONArray tValue;
	private String param;
	private JSONArray PredictedValue;
	/**
	 * @return the coeff
	 */
	public JSONArray getCoeff() {
		return this.Coeff;
	}
	/**
	 * @param coeff the coeff to set
	 */
	public void setCoeff(JSONArray coeff) {
		Coeff = coeff;
	}
	/**
	 * @return the stdError
	 */
	public JSONArray getStdError() {
		return this.StdError;
	}
	/**
	 * @param stdError the stdError to set
	 */
	public void setStdError(JSONArray stdError) {
		StdError = stdError;
	}
	/**
	 * @return the pValue
	 */
	public JSONArray getpValue() {
		return this.pValue;
	}
	/**
	 * @param pValue the pValue to set
	 */
	public void setpValue(JSONArray pValue) {
		this.pValue = pValue;
	}
	/**
	 * @return the tValue
	 */
	public JSONArray gettValue() {
		return this.tValue;
	}
	/**
	 * @param tValue the tValue to set
	 */
	public void settValue(JSONArray tValue) {
		this.tValue = tValue;
	}
	/**
	 * @return the param
	 */
	public String getParam() {
		return this.param;
	}
	/**
	 * @param param the param to set
	 */
	public void setParam(String param) {
		this.param = param;
	}
	/**
	 * @return the predictedValue
	 */
	public JSONArray getPredictedValue() {
		return this.PredictedValue;
	}
	/**
	 * @param predictedValue the predictedValue to set
	 */
	public void setPredictedValue(JSONArray predictedValue) {
		PredictedValue = predictedValue;
	}
	
	
	
	

}
